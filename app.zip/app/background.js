chrome.runtime.onMessage.addListener(handleRequest); // from content script and options.js
chrome.runtime.onMessageExternal.addListener(handleRequest); // from apps, and another extensions 

// require("escpos.js"); File

function handleRequest(request, sender, sendResponse) {
  console.log("message received from page",request);
  chrome.storage.local.get({
    "comport": 1,
    "mock": false,
    "printer_name" : "r58",
    "print_width" : 32,
    "print_encoding" : "windows1251",
  }, function(items) {
    

    if(request.operation == "printHTML"){
      request.operation = "print";
      request.mock = true;
      request.printer_name = items.printer_name;
      console.log("sendNativeMessage","printHTML");
      request.print_data = escpos.process(request.print_data,items.print_encoding,items.print_width);
    } else {
      console.log("sendNativeMessage");
      request.comport = +items.comport;
    }


    chrome.runtime.sendNativeMessage("io.smartpos.postoolat", request, 
      function(message) {
        if (chrome.runtime.lastError) {
            console.error("ERROR: " + chrome.runtime.lastError.message + " Host is io.smartpos.postoolat, please run chrome in verbose mode '--enable-logging --v=1'");
        } else {
            sendResponse(message);
        }
      }
    );
  });
  return true;
}